# Welcome contibutors!

You can contribute to LaserGRBL both by adding/improving translations or by submitting new features.
If you are not skilled enough to give coding support you can consider [donating to the project](https://paypal.me/pools/c/8cQ1Lo4sRA)

## Submit translation

If you want to contribute to the development of LaserGRBL by adding a translation in your language please read [how to translate](https://github.com/arkypita/LaserGRBL/blob/master/TRANSLATING.md)

## Submit code contribution

Code contibution should be submitted via Git "pull request" on LaserGRBL repository. If you want to contribute to the development of LaserGRBL adding new features and improving existing ones I guess you have some informatic skill that can point you to the right direction. If you are new to github environment you can find some guidelines here: https://help.github.com/en/desktop/contributing-to-projects
