//
// System.IO.Ports.SerialData.cs
//
// Authors:
//	Carlos Alberto Cortez (calberto.cortez@gmail.com)
//
// (c) Copyright 2006 Novell, Inc. (http://www.novell.com)
//

namespace MySerialPort 
{
	public enum SerialData 
	{
		Chars = 1,
		Eof
	} 
}

